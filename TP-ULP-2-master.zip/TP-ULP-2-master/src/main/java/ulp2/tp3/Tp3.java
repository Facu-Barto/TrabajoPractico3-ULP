/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ulp2.tp3;

/**
 *
 * @author diego
 */
public class Tp3 {

    public static void main(String[] args) {
        
    }
}
